import { ApiUrlInterceptor } from './api-url-interceptor';

describe('ApiInterceptor', () => {
  it('should create an instance', () => {
    expect(new ApiUrlInterceptor()).toBeTruthy();
  });
});
