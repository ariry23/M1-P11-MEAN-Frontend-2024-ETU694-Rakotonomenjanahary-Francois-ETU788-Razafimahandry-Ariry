import { Api } from './api';

describe('Api', () => {
  it('should create an instance', () => {
    expect(new Api()).toBeTruthy();
  });
});
