export class User {                 
    login : string;                 
    password : string;              
    firstName : string;                 
    lastName : string;                      
    email : string;             
}
