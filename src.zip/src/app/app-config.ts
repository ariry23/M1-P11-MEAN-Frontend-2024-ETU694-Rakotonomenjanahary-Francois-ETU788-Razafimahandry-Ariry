export class DattaConfig {
  static layout: string = 'vertical';
  static isCollapseMenu: Boolean = false;
}
