import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from 'src/app/core/services/api.service';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'] , 
  standalone: true,
  imports: [CommonModule, SharedModule],
})
export default class ListComponent implements OnInit {
  apiCount : number = 0 ; 
  isLoadingSubject  = new BehaviorSubject<boolean>(false);
  isLoading$ = this.isLoadingSubject.asObservable();
  constructor(private apiService: ApiService){}
  ngOnInit() {
    setTimeout(() => {
      this.apiService.getData('https://dummyjson.com/products').subscribe(
      data => {
        this.showLoader();
        let product = data.products ; 
        console.log(product) ; 
        this.hideLoader() ; 
         
       },
      error => {
        
       },
       () => {
         
       }
    )
    }, 500); 
    
  }


  showLoader() {
    if (this.apiCount === 0) {
      this.isLoadingSubject.next(true);
    }
    this.apiCount++;
  }

  hideLoader() {
    this.apiCount--;
    if (this.apiCount === 0) {
      this.isLoadingSubject.next(false);
    }
  }

}
