export const serviceConstant = {
    passwordRegex : /^(?=[^A-Z]*[A-Z])(?=[^a-z]*[a-z])(?=\D*\d).{8,}$/ , 
  };