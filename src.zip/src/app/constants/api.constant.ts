export const apiConstant = {
    userRegister : 'user/signup', 
};